package com.springbootprj.customerrelationshipmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerrelationshipmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
