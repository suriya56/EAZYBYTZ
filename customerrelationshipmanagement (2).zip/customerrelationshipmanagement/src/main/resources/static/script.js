document.addEventListener("DOMContentLoaded", function() {
    const contactForm = document.getElementById("contactForm");
    const salesForm = document.getElementById("salesForm");
    const taskForm = document.getElementById("taskForm");
    const supportForm = document.getElementById("supportForm");

    async function fetchAndDisplay(url, containerId) {
        const response = await fetch(url);
        const data = await response.json();
        const container = document.getElementById(containerId);
        container.innerHTML = "";
        data.forEach(item => {
            const div = document.createElement("div");
            div.textContent = JSON.stringify(item);
            container.appendChild(div);
        });
    }

    contactForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formData = new FormData(contactForm);
        const contact = Object.fromEntries(formData);
        await fetch("/api/contacts", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(contact)
        });
        fetchAndDisplay("/api/contacts", "contacts");
    });

    salesForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formData = new FormData(salesForm);
        const salesDeal = Object.fromEntries(formData);
        await fetch("/api/salesdeals", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(salesDeal)
        });
        fetchAndDisplay("/api/salesdeals", "salesDeals");
    });

    taskForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formData = new FormData(taskForm);
        const task = Object.fromEntries(formData);
        await fetch("/api/tasks", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(task)
        });
        fetchAndDisplay("/api/tasks", "tasks");
    });

    supportForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formData = new FormData(supportForm);
        const supportTicket = Object.fromEntries(formData);
        await fetch("/api/supporttickets", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(supportTicket)
        });
        fetchAndDisplay("/api/supporttickets", "supportTickets");
    });

    fetchAndDisplay("/api/contacts", "contacts");
    fetchAndDisplay("/api/salesdeals", "salesDeals");
    fetchAndDisplay("/api/tasks", "tasks");
    fetchAndDisplay("/api/supporttickets", "supportTickets");
});

