package com.springbootprj.customerrelationshipmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerrelationshipmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerrelationshipmanagementApplication.class, args);
	}

}